﻿namespace WebServiceAPI.Models
{
    public class MyDataModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
